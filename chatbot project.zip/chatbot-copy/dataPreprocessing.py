
# import necessary packages
import nltk
nltk.download('omw-1.4')
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
from nltk.tokenize import word_tokenize
import __init__
from __init__ import *
import logging
import pickle

class DataPreprocessing:
    def __init__(self) -> None:
        self.words=__init__.t.words
        self.classes=__init__.t.classes
        self.doc=__init__.t.doc
        self.ignore_words=__init__.t.ignore_words
        pass

    def preprocess(self):
        self.intents=__init__.t.intents
        try:
            for i in self.intents: 
                for p in i['patterns']:
                    w = nltk.word_tokenize(p)
                    self.words.extend(w)
                    self.doc.append((w,i["tag"]))
                    if i["tag"] not in self.classes:
                        self.classes.append(i["tag"])
            self.words=[lemmatizer.lemmatize(w.lower()) for w in self.words if w not in self.ignore_words]
            self.classes = sorted(list(set(self.classes)))
            file1=open('words.pkl','wb')
            file2=open('classes.pkl','wb')
            pickle.dump(self.words,file1)
            pickle.dump(self.classes,file2)
            return((self.words,self.classes,self.doc))
        except Exception as e:
            logging.exception("An error in preprocessing occurred: %s", e)

d=DataPreprocessing()