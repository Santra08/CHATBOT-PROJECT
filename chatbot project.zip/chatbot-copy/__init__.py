import json
class initialise:
    def __init__(self):
        self.words=[]
        self.classes=[]
        self.doc=[]
        self.ignore_words = ['?', '!','(',')']
        data_file = open(r"C:\Users\USER\OneDrive\Desktop\intents-1.json",encoding="utf8").read()
        self.intents = json.loads(data_file)['intents']
t=initialise()



