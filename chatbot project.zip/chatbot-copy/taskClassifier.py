
# import necessary packages
import random
import json
import logging
from keras.models import load_model
model = load_model('chatbot_model.h7')
from commonHandler import c
from taskHandler import th
from predictionModel import p 

class TaskClassifier:
    def __init__(self):
        pass
    
    def getResponse(self,int):
        try:
            print("entering getresponse")
            intents_json=json.loads(open(r"C:\Users\USER\OneDrive\Desktop\intents-1.json",encoding="utf8").read())
            tag = int[0]['intent']
            list_of_intents = intents_json['intents']
            for i in list_of_intents:
                if(i['tag']== tag):
                    result = random.choice(i['responses'])
                    break
            return result
        except Exception as e:
            logging.exception("An error %s", e)
    def response(self,phrase):
        #c.queryFiltering()
        #th.googleSearch()
        #th.getWeather()
        #th.scrape()
        print("getResponse and predict Conversation")
        int = p.predictCoversation(phrase, model)
        res = self.getResponse(int)
        return res
b = TaskClassifier()
print("Done")    
    