
# import necessary packages

# download necessary dependencies
from __init__ import t
import nltk
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import pickle

import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD
import random

class CommonHandler:

    def __init__(self) -> None:
        self.words = t.words
        self.intents =  t.intents
        self.classes = t.classes
        self.doc = t.doc
        self.ignore_words =t.ignore_words


    def queryFiltering(self):
        for i in  self.intents:
            for p in i['patterns']:

                w = nltk.word_tokenize(p)
                self.words.extend(w)
                self.doc.append((w,i['tag']))

                if i['tag'] not in self.classes:
                    self.classes.append(i['tag'])

    def printing(self):

        print(self.words)                  

c = CommonHandler()
c.queryFiltering()
c.printing()
