# import necessary packages
import nltk
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import pickle
import numpy as np
from keras.models import load_model
model = load_model('chatbot_model.h7')
import json
import random
import logging

class PredictionModel:
    
    def __init__(self) -> None:
        pass

    def preprocess(self, phrase):
        try:
            print("preprocess the user input by tokenization and lemmatization")
            phrase_words = nltk.word_tokenize(phrase)
            phrase_words = [lemmatizer.lemmatize(word.lower()) for word in phrase_words]
            return phrase_words
        except Exception as e:
            logging.exception("An error in processing occurred: %s", e)
    
    def bagOfWords(self, phrase,show_details=True):
        try:
            #(words =phrase_words)
            print("making it into bag of words")
            self.words = pickle.load(open('words.pkl','rb'))
            phrase_words=self.preprocess(phrase)
            bag = [0]*len(self.words) 
            for s in phrase_words:
                for i,w in enumerate(self.words):
                    print("printing iw")
                    print(i,w)
                    if w == s: 
                        bag[i] = 1
                        if show_details:
                            print ("found in bag: %s" % w)
            print("created bag of words")
            return(np.array(bag))
        except Exception as e:
            logging.exception("An error in froming bag of words: %s", e)

    def predictCoversation(self, phrase,model):
        try:
            print("model.predict")
            #model = load_model('chatbot_model.h6')
            self.words = pickle.load(open('words.pkl','rb'))
            self.classes = pickle.load(open('classes.pkl','rb'))
            self.response=self.bagOfWords(phrase, show_details= False)
            res = model.predict(np.array([self.response]))[0]
            ERROR_THRESHOLD = 0.25
            results = [[i,r] for i,r in enumerate(res) if r>ERROR_THRESHOLD]
            results.sort(key=lambda x: x[1], reverse=True)
            return_list = []
            for r in results:
                return_list.append({"intent": self.classes[r[0]], "probability": str(r[1])})
            print("classes and corresponding probabilities")
            return return_list
        except Exception as e:
            logging.exception("An error in predicting %s", e)

p=PredictionModel()

