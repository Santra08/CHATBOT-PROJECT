# import necessary packages
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD
from keras.models import load_model
import trainDataSplit as tds
from trainDataSplit import *
class ModelGeneration:
    
    def __init__(self) -> None:
        pass

    def modelChatbot(self):
        try:
            self.x_train,self.y_train=tds.t.dataCreator()
            print("entering the process of creating model")
            model = Sequential()
            model.add(Dense(128, input_shape=(len(self.x_train[0]),), activation='relu'))
            model.add(Dropout(0.5))
            model.add(Dense(64, activation='relu'))
            model.add(Dropout(0.5))
            model.add(Dense(len(self.y_train[0]), activation='softmax'))
            sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
            model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
            return (model,self.x_train,self.y_train)

        except Exception as e:
            logging.exception("An error in compiling the model has occurred: %s", e)


    def train(self):
        """
        *This function will build a deep neural network that has specified layers mentioned in modelChatbot() function.
        The process happening in this code block is mentioned below:
        1. load the model and traing file from modelChatbot() function
        2. fit the model with appropriate callbacks and fine tune the model.

        """
        try:
            model,self.x_train,self.y_train= self.modelChatbot()
            print('fitting the model')
            hist = model.fit(np.array(self.x_train), np.array(self.y_train), epochs=200, batch_size=5, verbose=1)
            model.save('chatbot_model.h7', hist)
            print("created chatbot_model.h7")
            return model
        except Exception as e:
            logging.exception("An error in fitting the model has occurred: %s", e)

m=ModelGeneration()
print("done model generation")