# import necessary packages
import webbrowser
import urllib.parse

class TaskHandler:
    def _init_(self):
        pass
    
    def googleSearch(self,phrase):
        import webbrowser
        #a = input("enter what you want to search:")
        c = phrase.split()
        b = "+".join(c)
        wp = "https://www.google.com/search?q={}".format(b)
        return webbrowser.open(wp)
        
    def getWeather(self,a):
        import requests
        #a = input("enter the palce: ")
        params = {
            'access_key': '3787ded0c28ec41961aed5c8eb6ea46b',
            'query': a    
        }
    
        api_result = requests.get('http://api.weatherstack.com/current', params)

        api_response = api_result.json()
        #print(api_response)
        print(u'Current temperature in %s is %d℃' % (api_response['location']['name'], api_response['current']['temperature']))
        print(u'Current wind speed in %s is %dkm/h' % (api_response['location']['name'], api_response['current']['wind_speed']))
        
        
    def scrape(self,phrase):
        import wikipediaapi
        wikipedia = wikipediaapi.Wikipedia(language='en', extract_format=wikipediaapi.ExtractFormat.WIKI)
        page = wikipedia.page(phrase)
        #return page.text[0:10000]
        return page.summary
        
th=TaskHandler()